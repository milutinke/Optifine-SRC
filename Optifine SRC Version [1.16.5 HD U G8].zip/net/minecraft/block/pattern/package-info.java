@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block.pattern;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;