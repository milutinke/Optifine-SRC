package net.minecraft.client.gui.recipebook;

public interface IRecipeShownListener
{
    void recipesUpdated();

    RecipeBookGui getRecipeGui();
}
