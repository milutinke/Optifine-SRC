@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.gui.fonts;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;