package net.minecraft.client.gui;

import java.util.List;
import java.util.Optional;
import net.minecraft.util.IReorderingProcessor;

public interface IBidiTooltip
{
    Optional<List<IReorderingProcessor>> func_241867_d();
}
