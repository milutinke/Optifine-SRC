@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.gui.overlay;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;