package com.mojang.realmsclient.exception;

public class RealmsHttpException extends RuntimeException
{
    public RealmsHttpException(String p_i51786_1_, Exception p_i51786_2_)
    {
        super(p_i51786_1_, p_i51786_2_);
    }
}
