package com.mojang.blaze3d.systems;

public interface IRenderCall
{
    void execute();
}
