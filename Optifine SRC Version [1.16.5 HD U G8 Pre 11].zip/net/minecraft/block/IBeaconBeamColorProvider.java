package net.minecraft.block;

import net.minecraft.item.DyeColor;

public interface IBeaconBeamColorProvider
{
    DyeColor getColor();
}
