package net.minecraft.block;

public class GlassBlock extends AbstractGlassBlock
{
    public GlassBlock(AbstractBlock.Properties properties)
    {
        super(properties);
    }
}
